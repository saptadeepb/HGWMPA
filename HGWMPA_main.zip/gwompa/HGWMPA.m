function [Best_score, Best_position, HGWMPA_Convergence_curve] = HGWMPA(N, Max_iter, LB, UB, Dim, F_obj)
    display('HGWMPA is optimizing your problem');
    
    % Initialize parameters for GWO
    Alpha_pos = zeros(1, Dim);
    Alpha_score = inf;
    Beta_pos = zeros(1, Dim);
    Beta_score = inf;
    Delta_pos = zeros(1, Dim);
    Delta_score = inf;

    % Initialize positions of search agents
    Positions = initialization(N, Dim, UB, LB);
    HGWMPA_Convergence_curve = zeros(1, Max_iter);

    % Main loop
    for t = 1:Max_iter
        % Adaptive control for exploration-exploitation balance
        a = 2 - t * (2 / Max_iter); % Linearly decreasing factor for GWO dynamics
        
        % Evaluate fitness and update Alpha, Beta, and Delta positions
        for i = 1:N
            % Enforce boundary constraints
            Positions(i, :) = max(min(Positions(i, :), UB), LB);

            % Compute fitness
            fitness = F_obj( Positions(i, :));
            
            % Update Alpha, Beta, and Delta positions
            if fitness < Alpha_score
                Delta_score = Beta_score;  % Update delta
                Delta_pos = Beta_pos;
                
                Beta_score = Alpha_score;  % Update beta
                Beta_pos = Alpha_pos;
                
                Alpha_score = fitness;  % Update alpha
                Alpha_pos = Positions(i, :);
            elseif fitness < Beta_score
                Delta_score = Beta_score;
                Delta_pos = Beta_pos;
                
                Beta_score = fitness;
                Beta_pos = Positions(i, :);
            elseif fitness < Delta_score
                Delta_score = fitness;
                Delta_pos = Positions(i, :);
            end
        end

        % Update Positions with GWMPA hybrid dynamics
        if t < 0.5 * Max_iter
            % Exploration phase with MPA influence
            RB = rand(N, Dim);
            X_rand = LB + (UB - LB) .* rand(N, Dim);
            Positions = Positions + RB .* (X_rand - Positions) .* (rand * 2 - 1);
        else
            % Exploitation phase with GWO dynamics
            for i = 1:N
                for j = 1:Dim
                    % Alpha component
                    r1 = rand();
                    r2 = rand();
                    A1 = 2 * a * r1 - a;
                    C1 = 2 * r2;
                    D_alpha = abs(C1 * Alpha_pos(j) - Positions(i, j));
                    X1 = Alpha_pos(j) - A1 * D_alpha;

                    % Beta component
                    r1 = rand();
                    r2 = rand();
                    A2 = 2 * a * r1 - a;
                    C2 = 2 * r2;
                    D_beta = abs(C2 * Beta_pos(j) - Positions(i, j));
                    X2 = Beta_pos(j) - A2 * D_beta;

                    % Delta component
                    r1 = rand();
                    r2 = rand();
                    A3 = 2 * a * r1 - a;
                    C3 = 2 * r2;
                    D_delta = abs(C3 * Delta_pos(j) - Positions(i, j));
                    X3 = Delta_pos(j) - A3 * D_delta;

                    % Combine components with adaptive step size
                    Positions(i, j) = (X1 + X2 + X3) / 3;
                end
            end
        end

        % Record convergence curve
        HGWMPA_Convergence_curve(t) = Alpha_score;

        % Display current best solution every 100 iterations
        if mod(t, 100) == 0
            display(['At iteration ', num2str(t), ' the best solution fitness is ', num2str(Alpha_score)]);
        end
    end

    % Return results
    Best_score = Alpha_score;
    Best_position = Alpha_pos;
end
