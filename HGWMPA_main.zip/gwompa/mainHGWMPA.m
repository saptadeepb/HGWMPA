%  Chatic Crayfish Optimization Algorithm(COA)
%
%  Source codes demo version 1.0                                                                      
%                                                                                                     
%  The 11th Gen Intel(R) Core(TM) i7-11700 processor with the primary frequency of 2.50GHz, 16GB memory, and the operating system of 64-bit windows 11 using matlab2021a.                                                                
%                                                                                                     
%  Author and programmer: Binanda maiti;Saptadeep Biswas.                                                                          
%         e-Mail: matheaticsbinanda@gmail.com;saptadeepb1994@gmail.com                                                                                                                                                                                                                                              


clear all 
close all
clc

N=100;  %Number of search agents
F_name='F1';     %Name of the test function
Max_iter=500;           %Maximum number of iterations

    
[LB,UB,Dim, F_obj]=Get_F(F_name); %Get details of the benchmark functions
[Best_score, Best_position, HGWMPA_Convergence_curve] = HGWMPA(N, Max_iter, LB, UB, Dim, F_obj);

figure('Position',[454   445   694   297]);
subplot(1,3,1); % Corrected 'sUBplot' to 'subplot'
func_plot(F_name);     % Function plot
title('Parameter space')
xlabel('x_1');
ylabel('x_2');
zlabel([F_name,'( x_1 , x_2 )'])

subplot(1,3,2);       % Convergence plot
semilogy(HGWMPA_Convergence_curve,'LineWidth',3)
xlabel('Iteration#');
ylabel('Fitness Value');
title('HGWMPA_Convergence_curve');

% subplot(1,3,3);       % Another convergence plot
% semilogy(Best_position,'LineWidth',3)
% xlabel('Iteration#');
% ylabel('Diversity (or coverage)');
% title('Global Convergence');
% legend('HGWMPA');


display(['The best-obtained solution by HGWMPA is : ', num2str(Best_position)]);  
display(['The best optimal value of the objective funciton found by HGWMPA is : ', num2str(Best_score)]);  